"use client"

import { useState, useEffect } from "react"
import { MessageSquare, X, Minimize2, Maximize2 } from "lucide-react"

export default function DialogflowChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [chatbotLoaded, setChatbotLoaded] = useState(false)

  useEffect(() => {
    // This would be replaced with the actual Dialogflow embed code
    if (isOpen && !chatbotLoaded) {
      // Simulating the loading of the Dialogflow script
      console.log("Loading Dialogflow chatbot...")
      setChatbotLoaded(true)

      // In a real implementation, you would load the Dialogflow script here
      // Example:
      // const script = document.createElement('script');
      // script.src = 'https://www.gstatic.com/dialogflow-console/fast/messenger/bootstrap.js?v=1';
      // script.async = true;
      // document.body.appendChild(script);
    }
  }, [isOpen, chatbotLoaded])

  return (
    <>
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 bg-gray-800 hover:bg-gray-700 text-white p-4 rounded-full shadow-lg z-50"
          aria-label="Open Chatbot"
        >
          <MessageSquare className="h-6 w-6" />
        </button>
      ) : (
        <div
          className={`fixed bottom-6 right-6 bg-gray-900 border border-gray-800 rounded-lg shadow-xl z-50 transition-all duration-300 ${
            isMinimized ? "w-72" : "w-80 sm:w-96"
          }`}
        >
          <div className="flex items-center justify-between p-4 border-b border-gray-800">
            <h3 className="font-medium">Chat with us</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="text-gray-400 hover:text-white"
                aria-label={isMinimized ? "Maximize" : "Minimize"}
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </button>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white" aria-label="Close">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <div className="h-96 p-4">
              {/* This is where the Dialogflow chat widget would be embedded */}
              <div className="flex items-center justify-center h-full text-gray-400">
                <p>Dialogflow chatbot would be embedded here.</p>
                {/* In a real implementation, you would add the Dialogflow chat element here */}
                {/* Example: <df-messenger chat-title="Chat with us" agent-id="YOUR_AGENT_ID" language-code="en"></df-messenger> */}
              </div>
            </div>
          )}
        </div>
      )}
    </>
  )
}
